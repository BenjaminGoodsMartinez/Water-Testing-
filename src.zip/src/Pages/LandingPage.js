import React from "react";
import '../css/uikit.min.css';
import Logo from '../Images/SpartanLogo.png';
import '../css/LandingPage.css';
import watertestingheader from '../Images/Water Testing Header-1.png';


class LandingPage extends React.Component {


    render() {

        let logo = <img className = 'Logo' src={Logo}/>
        let header = <img className="WaterTestingHeader" src={watertestingheader}/>

        return (

            <div> 
                <nav class="uk-navbar-container uk-margin" uk-navbar="mode: click">
                    <div class="uk-navbar-left">

                        <ul class="uk-navbar-nav">
                            <li>{logo}</li>
                            <li><a href="#">About</a></li>
                            <li>
                                
                                <a href="#">Testing Kit</a>
                                <div class="uk-navbar-dropdown">
                                    <ul class="uk-nav uk-navbar-dropdown-nav">
                                        <li class="uk-active"><a href="#">Active</a></li>
                                        <li><a href="#">Item</a></li>
                                        <li><a href="#">Item</a></li>
                                    </ul>
                                </div>
                            </li>
                            <li><a href="#">Contact Us</a></li>
                            <li><a href="#">Sign Up</a></li>
                            
                        </ul>

                    </div>
                </nav>



                <div>
                    {header}

                </div>



              
            </div>

        )




    }








}

export default LandingPage;